package com.gym.management.service.impl;

import com.gym.management.entity.GymCheckIn;
import com.gym.management.exception.BusinessException;
import com.gym.management.exception.ErrorCode;
import com.gym.management.repository.GymCheckInRepository;
import com.gym.management.service.GymCheckInService;
import com.gym.management.service.MembershipLookupPort;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GymCheckInServiceImplTest {

    private static final LocalDateTime NOW = LocalDateTime.of(2026, 10, 25, 18, 0);

    @Mock private GymCheckInRepository gymCheckInRepository;
    @Mock private MembershipLookupPort membershipLookupPort;
    @InjectMocks private GymCheckInServiceImpl service;

    private final UUID memberId = UUID.randomUUID();

    private GymCheckIn openCheckIn(LocalDateTime checkInTime) {
        GymCheckIn c = new GymCheckIn();
        c.setMemberId(memberId);
        c.setCheckInTime(checkInTime);
        return c;
    }

    @Test
    void firstScan_withActiveMembership_createsCheckIn() {
        when(gymCheckInRepository.findFirstByMemberIdOrderByCheckInTimeDesc(memberId)).thenReturn(Optional.empty());
        when(membershipLookupPort.resolveActiveMembership(memberId))
                .thenReturn(new MembershipLookupPort.ActiveMembership(null, null, LocalDate.of(2026, 12, 31)));
        when(gymCheckInRepository.save(any(GymCheckIn.class))).thenAnswer(i -> i.getArgument(0));

        GymCheckInService.ScanResult result = service.recordFaceScan(memberId, NOW);

        assertThat(result.action()).isEqualTo(GymCheckInService.ACTION_CHECK_IN);
        ArgumentCaptor<GymCheckIn> captor = ArgumentCaptor.forClass(GymCheckIn.class);
        verify(gymCheckInRepository).save(captor.capture());
        assertThat(captor.getValue().getMemberId()).isEqualTo(memberId);
        assertThat(captor.getValue().getCheckInTime()).isEqualTo(NOW);
        assertThat(captor.getValue().getCheckOutTime()).isNull();
        assertThat(captor.getValue().getMethod()).isEqualTo("FACE");
        assertThat(captor.getValue().getBranchId()).isNull();
    }

    @Test
    void firstScan_withoutActiveMembership_throwsMembershipExpired_andSavesNothing() {
        when(gymCheckInRepository.findFirstByMemberIdOrderByCheckInTimeDesc(memberId)).thenReturn(Optional.empty());
        when(membershipLookupPort.resolveActiveMembership(memberId))
                .thenThrow(new BusinessException(ErrorCode.MEMBERSHIP_NOT_FOUND, "no active"));

        assertThatThrownBy(() -> service.recordFaceScan(memberId, NOW))
                .isInstanceOf(BusinessException.class)
                .hasFieldOrPropertyWithValue("errorCode", ErrorCode.MEMBERSHIP_EXPIRED);

        verify(gymCheckInRepository, never()).save(any());
    }

    @Test
    void openCheckInSameDay_secondScanIsCheckOut_withoutMembershipCheck() {
        GymCheckIn open = openCheckIn(NOW.minusHours(1));
        when(gymCheckInRepository.findFirstByMemberIdOrderByCheckInTimeDesc(memberId)).thenReturn(Optional.of(open));

        GymCheckInService.ScanResult result = service.recordFaceScan(memberId, NOW);

        assertThat(result.action()).isEqualTo(GymCheckInService.ACTION_CHECK_OUT);
        assertThat(open.getCheckOutTime()).isEqualTo(NOW);
        verify(gymCheckInRepository).save(open);
        verifyNoInteractions(membershipLookupPort);
    }

    @Test
    void closedCheckIn_nextScanCreatesNewCheckIn() {
        GymCheckIn closed = openCheckIn(NOW.minusHours(3));
        closed.setCheckOutTime(NOW.minusHours(2));
        when(gymCheckInRepository.findFirstByMemberIdOrderByCheckInTimeDesc(memberId)).thenReturn(Optional.of(closed));
        when(membershipLookupPort.resolveActiveMembership(memberId))
                .thenReturn(new MembershipLookupPort.ActiveMembership(null, null, null));
        when(gymCheckInRepository.save(any(GymCheckIn.class))).thenAnswer(i -> i.getArgument(0));

        GymCheckInService.ScanResult result = service.recordFaceScan(memberId, NOW);

        assertThat(result.action()).isEqualTo(GymCheckInService.ACTION_CHECK_IN);
        verify(gymCheckInRepository).save(argThat(c -> c != closed && c.getCheckInTime().equals(NOW)));
    }

    @Test
    void openCheckInFromPreviousDay_isNotClosed_newCheckInCreated() {
        GymCheckIn stale = openCheckIn(NOW.minusDays(1));
        when(gymCheckInRepository.findFirstByMemberIdOrderByCheckInTimeDesc(memberId)).thenReturn(Optional.of(stale));
        when(membershipLookupPort.resolveActiveMembership(memberId))
                .thenReturn(new MembershipLookupPort.ActiveMembership(null, null, null));
        when(gymCheckInRepository.save(any(GymCheckIn.class))).thenAnswer(i -> i.getArgument(0));

        GymCheckInService.ScanResult result = service.recordFaceScan(memberId, NOW);

        assertThat(result.action()).isEqualTo(GymCheckInService.ACTION_CHECK_IN);
        assertThat(stale.getCheckOutTime()).isNull();
    }
}
