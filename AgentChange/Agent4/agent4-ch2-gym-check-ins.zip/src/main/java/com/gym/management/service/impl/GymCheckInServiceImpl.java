package com.gym.management.service.impl;

import com.gym.management.entity.GymCheckIn;
import com.gym.management.exception.BusinessException;
import com.gym.management.exception.ErrorCode;
import com.gym.management.repository.GymCheckInRepository;
import com.gym.management.service.GymCheckInService;
import com.gym.management.service.MembershipLookupPort;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class GymCheckInServiceImpl implements GymCheckInService {

    private final GymCheckInRepository gymCheckInRepository;
    private final MembershipLookupPort membershipLookupPort;

    @Override
    @Transactional
    public ScanResult recordFaceScan(UUID memberId, LocalDateTime now) {
        Optional<GymCheckIn> last = gymCheckInRepository.findFirstByMemberIdOrderByCheckInTimeDesc(memberId);

        // Lượt đang mở trong cùng ngày: lần quét này là check-out (không cần kiểm tra gói,
        // để hội viên vẫn ra được khi gói vừa hết hạn trong lúc đang tập).
        if (last.isPresent()
                && last.get().getCheckOutTime() == null
                && last.get().getCheckInTime().toLocalDate().equals(now.toLocalDate())) {
            GymCheckIn open = last.get();
            open.setCheckOutTime(now);
            gymCheckInRepository.save(open);
            return new ScanResult(ACTION_CHECK_OUT, open.getId());
        }

        requireActiveMembership(memberId);

        GymCheckIn checkIn = new GymCheckIn();
        checkIn.setMemberId(memberId);
        checkIn.setCheckInTime(now);
        checkIn.setMethod("FACE");
        GymCheckIn saved = gymCheckInRepository.save(checkIn);
        return new ScanResult(ACTION_CHECK_IN, saved.getId());
    }

    private void requireActiveMembership(UUID memberId) {
        try {
            membershipLookupPort.resolveActiveMembership(memberId);
        } catch (BusinessException e) {
            // resolveActiveMembership chỉ ném MEMBERSHIP_NOT_FOUND khi không có gói ACTIVE;
            // thiết kế CH2 yêu cầu báo MEMBERSHIP_EXPIRED cho lượt vào phòng.
            throw new BusinessException(ErrorCode.MEMBERSHIP_EXPIRED,
                    "Hội viên không có gói tập đang hiệu lực");
        }
    }
}
